console.log('auth-service placeholder listo');
