import { Router } from 'express';
import { makeMulter } from '../middleware/pdfOnly.js';
import { promises as fs } from 'fs';
import path from 'path';

export function buildFilesRouter(uploadDir: string, maxFileSizeBytes: number) {
  const router = Router();
  const upload = makeMulter(uploadDir, maxFileSizeBytes);

  router.get('/healthz', (_req, res) => res.json({ ok: true }));

  router.post('/upload', upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No se recibió archivo' });
    res.status(201).json({ message: 'Archivo subido', file: req.file.filename });
  });

  router.get('/files', async (_req, res) => {
    const files = await fs.readdir(uploadDir);
    res.json(files);
  });

  router.get('/files/:name', async (req, res) => {
    try {
      const filePath = path.join(uploadDir, req.params.name);
      res.download(filePath);
    } catch {
      res.status(404).json({ error: 'Archivo no encontrado' });
    }
  });

  router.delete('/files/:name', async (req, res) => {
    try {
      await fs.unlink(path.join(uploadDir, req.params.name));
      res.json({ message: 'Archivo eliminado' });
    } catch {
      res.status(404).json({ error: 'Archivo no encontrado' });
    }
  });

  return router;
}
