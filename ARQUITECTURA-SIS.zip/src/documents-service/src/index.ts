import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import path from 'path';
import { ensureDir } from './utils/fsAsync.js';
import { buildFilesRouter } from './routes/files.routes.js';

dotenv.config();

const PORT = process.env.PORT || 4002;
const UPLOADS_DIR = process.env.UPLOADS_DIR || 'uploads';
const app = express();
app.use(helmet());
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());
await ensureDir(path.resolve(UPLOADS_DIR));
app.use('/api', buildFilesRouter(path.resolve(UPLOADS_DIR), 25*1024*1024));
app.listen(PORT, () => console.log(`documents-service en puerto ${PORT}`));
