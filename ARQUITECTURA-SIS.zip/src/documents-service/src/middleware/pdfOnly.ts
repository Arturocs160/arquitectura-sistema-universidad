import multer from 'multer';
import path from 'path';

export function makeMulter(uploadDir: string, maxFileSizeBytes: number) {
  const storage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => {
      const safe = file.originalname.replace(/\s+/g, '_');
      cb(null, Date.now() + '-' + safe);
    }
  });

  const fileFilter: multer.Options['fileFilter'] = (_req, file, cb) => {
    const isPdf = file.mimetype === 'application/pdf' || path.extname(file.originalname).toLowerCase() === '.pdf';
    if (!isPdf) return cb(new Error('Solo se permiten archivos PDF'));
    cb(null, true);
  };

  return multer({ storage, fileFilter, limits: { fileSize: maxFileSizeBytes } });
}
