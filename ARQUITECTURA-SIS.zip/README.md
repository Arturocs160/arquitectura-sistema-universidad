# Arquitectura – Microservicios

Contiene microservicio documents-service para subir PDFs.
